
int  mapmem (int pin);
void dis (int pin, int * b1);
int  opcode_len (int opcode);
char * get_opcode_model (int opcode);
int get_a12(int pin);   
int get_r16(int pin);
int get_a16(int pin);
int get_r8(int pin);
int get_d9(int pin);
int get_d9bit(int pin);
int get_reg(int pin);
void print_data_label (int addr);
void print_code_label (int addr, int formatted);
int checkmem(void);


//---0---- ---1---- --2,3--- --4-7--- --8-F---


// Format: 5 chars=NAME
//         1 char= param   template
//                  =      nop
//                 2=a12   absolute
//                 6=r16   relative 16
//                 7=a16   absolute 16
//                 8=r8    relative 8
//                 9=d9 
//                 @=@Ri   indirect
//                 #=#i8   immediate
//                 ^=#i8,d9 immediate
//                 %=#i8,@Ri   
//                 b=d9,b3    bit manipulation
//                 r=d9,b3,r8 bit branch
//                 z=#i8,r8
//                 x=d9,r8
//                 v=@Ri,#i8,r8
//                 c=@Ri,r8
//                 !       invalid!!


char op[5*16][8] =
//---0---- ---1---- --2,3--- --4-7--- --8-F---
 {"NOP   ","BR   8","LD   9","LD   @","CALL 2",
  "CALLR6","BRF  6","ST   9","ST   @","CALL 2",
  "CALLF7","JMPF 7","MOV  ^","MOV  %","JMP  2",
  "MUL   ","BE   z","BE   x","BE   v","JMP  2",
  "DIV   ","BNE  z","BNE  x","BNE  v","ERR  !",
  "ERR  !","ERR  !","DBNZ x","DBNZ c","ERR  !",
  "PUSH 9","PUSH 9","INC  9","INC  @","BP   r",
  "POP  9","POP  9","DEC  9","DEC  @","BP   r",
  "BZ   8","ADD  #","ADD  9","ADD  @","BN   r",
  "BNZ  8","ADDC #","ADDC 9","ADDC @","BN   r",
  "RET   ","SUB  #","SUB  9","SUB  @","NOT1 b",
  "RETI  ","SUBC #","SUBC 9","SUBC @","NOT1 b",
  "ROR   ","LDC   ","XCH  9","XCH  @","CLR1 b",
  "RORC  ","OR   #","OR   9","OR   @","CLR1 b",
  "ROL   ","AND  #","AND  9","AND  @","SET1 b",
  "ROLC  ","XOR  #","XOR  9","XOR  @","SET1 b",
 };


#define MEM_UNUSED       0
#define MEM_UNKNOWN      1  // used, but unknown yet.
#define MEM_CODE         2
#define MEM_CODE_LABELED 3
#define MEM_DATA         4
#define MEM_GRAPHICS     5
#define MEM_INVALID      6  // can't determine proper usage.


typedef struct {int addr; char * text;} addrlist_type;


// This list need not be ordered because i'm lazy. And the VMU doesn't produce that
// much code that a decent computer can't cut through it all quick enough.
//
// This portion provided by Alexander Villagran -- thanks!

addrlist_type SFR[] =
  {   { 0x100, "ACC" }, 
      { 0x101, "PSW" }, 
      { 0x102, "B" }, 
      { 0x103, "C" },     // C Register 
      { 0x104, "TRL" }, 
      { 0x105, "TRH" }, 
      { 0x106, "SP" }, 
      { 0x107, "PCON" }, 
      { 0x108, "IE" }, 
      { 0x109, "IP" },    // Interrupt Priority Ranking Control Register 
      // 0x10A - 0x10C - Not Used 
      { 0x10D, "EXT" },   // External Memory Control Register
      { 0x10e, "OCR"},    // Oscillation Control Register - Picks either 32Khz, 600Khz (flash and LCD), and 5 Mhz (Dreamcast Connected) 
      // 0x10f - Not Used 
      { 0x110, "T0CON" }, // Timer/Counter 0 Control Register 
      { 0x111, "T0PRR" }, // Timer 0 Prescaler Data Register 
      { 0x112, "T0L" }, 
      { 0x113, "T0LR" },  // Timer 0 Low Reload Register 
      { 0x114, "T0H" }, 
      { 0x115, "T0HR" },  // Timer 0 High Reload Register 
      // 0x116-0x117 - Not Used 
      { 0x118, "T1CNT" }, // Timer 1 Control Register 
      // 0x119 - Not Used 
      { 0x11A, "T1LC" },  // Timer 1 Low Compare Data Register 
      { 0x11B, "T1L" },   // Timer 1 Low Register 
      { 0x11B, "T1LR" },  // Timer 1 Low Reload Register 
      { 0x11C, "T1HC" },  // Timer 1 High Compare Data Register 
      { 0x11D, "T1H" },   // Timer 1 High Register 
      { 0x11D, "T1HR" },  // Timer 1 High Reload Register 
      // 0x11E - 0x11F - Not used 
      { 0x120, "MCR"},    // Mode Control Register 
      // 0x121 - Not Used 
      { 0x122, "STAD" },  // Start Addresss Register 
      { 0x123, "CNR" },   // Character Number Register 
      { 0x124, "TDR" },   // Time Division Register 
      { 0x125, "XBNK"},   // Bank Address Register 
      // 0x126 - Not Used 
      { 0x127, "VCCR"},   // LCD Contrast Control Register 
      // 0x128-0x12f - Not Used 
      { 0x130, "SCON0"},  // SIO0 Control Register 
      { 0x131, "SBUF0"},  // SIO0 Buffer 
      { 0x132, "SBR"},    // SIO Baud Rate Generator Register 
      // 0x133 - Not Used 
      { 0x134, "SCON1" }, // SIO1 Control Register 
      { 0x135, "SBUF1" }, // SIO1 Buffer 
      // 0x136-0x143 - Not Used 
      { 0x144, "P1" }, 
      { 0x145, "P1DDR"}, 
      { 0x146, "P1FCR"},  // Port 1 Function Control Register 
      // 0x147-0x14b - Not Used 
      { 0x14c, "P3" }, 
      { 0x14d, "P3DDR"}, 
      { 0x14e, "P3INT"}, 
      // 0x14F-0x15B - Not Used 
      { 0x15C, "P7" },    // Port 7 Latch 
      { 0x15D, "I01CR" }, // External Interrupt 0, 1 Control Register 
      { 0x15E, "I23CR" }, // External Interrupt 2, 3 Control Register 
      { 0x15F, "ISL" },   // Input Signal Selection Register 
      // 0x160 - 0x162 - Not Used 
      { 0x163, "VSEL"},   // VMS Control Register 
      { 0x164, "VRMAD1"}, // Work RAM Access Address 1 
      { 0x165, "VRMAD2"}, // Work RAM Access Address 2 
      { 0x166, "VTRBF"},  // Send/Receive Buffer 
      { 0x167, "VLREG"},  // Length registration 
      // 0x168-0x17E - Not Used 
      { 0x17F, "BTCR" },  // Base Timer Control Register 
      { 0x180, "XRAM" },  // 0x180-0x1FB - XRAM (Bank 0)[Lines 0 -> 15] 
      { 0x180, "XRAM" },  // 0x180-0x1FB - XRAM (Bank 1)[Lines 16 -> 31] 
      { 0x180, "XRAM" },  // 0x180-0x185 - XRAM (Bank 2)[4 Icons on bottom of LCD - DO NOT USE!] 
      // 0x1FB - 0x1FF - Not Used 
      { -1, "EOL"}        // ---End of list---
      }; 


// predefined label list: 
addrlist_type LABELS[] =
   {  { 0x0000, "reset"},  // Reset
      { 0x0003, "EINT0"},  // 0x0003 external interrupt 0?
      { 0x000b, "iT0"},  // 0x000b timer/counter 0 interrupt
      { 0x0013, "iEINT1"},  // 0x0013 external interrupt 1?
      { 0x001b, "iT1"},  // 0x001b timer/counter 1 interrupt
      { 0x0023, "iP3"},  // 0x0023 divider circuit/port 1/port 3 interrupt?
      { 0x002b, "int2B"},  // 0x002b interrupt - unknown
      { 0x0033, "int33"},  // 0x0033 interrupt - unknown
      { 0x003b, "int3B"},  // 0x003b interrupt - unknown
      { 0x0043, "int43"},  // 0x0043 interrupt - unknown
      { 0x004b, "int4B"},  // 0x004b interrupt - unknown, but used by football program
      { 0x0100, "int100link"},   // link to ROM code
      { 0x0110, "int110link"},   // link to ROM code
      { 0x0120, "int120link"},   // link to ROM code
      { 0x0130, "intT1link"},   // link to ROM's T1 interrupt code
      { 0x01f0, "quit"},   // exit vector
      { -1, "EOL"}        // ---End of list---
   };


typedef struct {int code[3]; char * text;} codelist_type;

// predefined code comments list:
codelist_type CODECMTS[] =
   {  { {0xB8, 0x0D,   -1}, ";execute code in other bank"},  // NOT1   EXT, 0
      { {0x23, 0x4c, 0xFF}, "     ;allow us to read buttons"},    // MOV    #$ff,P3  
     
      { {0x98, 0x4c,   -1}, ";branch if up button pressed"},    // BN     P3, 0, xxx
      { {0x99, 0x4c,   -1}, ";branch if down button pressed"},  // BN     P3, 1, xxx
      { {0x9a, 0x4c,   -1}, ";branch if left button pressed"},  // BN     P3, 2, xxx
      { {0x9b, 0x4c,   -1}, ";branch if right button pressed"}, // BN     P3, 3, xxx
      { {0x9c, 0x4c,   -1}, ";branch if A button pressed"},     // BN     P3, 4, xxx
      { {0x9d, 0x4c,   -1}, ";branch if B button pressed"},     // BN     P3, 5, xxx
      { {0x9e, 0x4c,   -1}, ";branch if Mode button pressed"},  // BN     P3, 6, xxx
      { {0x9f, 0x4c,   -1}, ";branch if Sleep button pressed"}, // BN     P3, 7. xxx
     
      { {0x78, 0x4c,   -1}, ";branch if up button isn't pressed"},    // BP     P3, 0, xxx
      { {0x79, 0x4c,   -1}, ";branch if down button isn't pressed"},  // BP     P3, 1, xxx
      { {0x7a, 0x4c,   -1}, ";branch if left button isn't pressed"},  // BP     P3, 2, xxx
      { {0x7b, 0x4c,   -1}, ";branch if right button isn't pressed"}, // BP     P3, 3, xxx
      { {0x7c, 0x4c,   -1}, ";branch if A button isn't pressed"},     // BP     P3, 4, xxx
      { {0x7d, 0x4c,   -1}, ";branch if B button isn't pressed"},     // BP     P3, 5, xxx
      { {0x7e, 0x4c,   -1}, ";branch if Mode button isn't pressed"},  // BP     P3, 6, xxx
      { {0x7f, 0x4c,   -1}, ";branch if Sleep button isn't pressed"}, // BP     P3, 7. xxx
      { {0x03, 0x4c,   -1}, "          ;read buttons"}, //  LD     P3

      { {0x78, 0x5c,   -1}, ";branch if Dreamcast connected"}, // BP     P7, 0, L05E4
      { {0x98, 0x5c,   -1}, ";branch if Dreamcast isn't connected"}, // BN     P7, 0, L05E4

      { {0x23, 0x27, 0x00}, "   ;turn off LCD"},                 // MOV    #$00,VCCR
      { {0x23, 0x27, 0x80}, "   ;turn on LCD"},                  // MOV    #$00,VCCR
      { {0xf8, 0x07,   -1}, "     ;halt- sleep until interrupt"},    // SET1   PCON, 0

      { {0x03, 0x66,   -1}, " ;read from work RAM"}, //  LD     VTRBF
      { {0x13, 0x66,   -1}, " ;write to work RAM"},  //  ST     VTRBF

      { {0x23, 0x0e, 0xa1}, "    ;set clock speed, normal (fast?)"},    //   MOV    #$a1,OCR
      { {0x23, 0x0e, 0x81}, "    ;set clock speed, LCD speed (slow?)"}, //   MOV    #$81,OCR

      { {0xfd, 0x0e,   -1}, ";set clock speed, normal (fast?)"},    //   SET1   OCR,5   
      { {0xdd, 0x0e,   -1}, ";set clock speed, LCD speed (slow?)"}, //   CLR1   OCR,5  

      { {0xdf, 0x08,   -1}, " ;disable all interrupts"},         // CLR1   IE, 7
      { {0xd8, 0x4e,   -1}, "    ;disable port 3 interrupts"},   //  CLR1   P3INT, 0
      { {0xf8, 0x4e,   -1}, "    ;enable port 3 interrupts"},    //  SET1   P3INT, 0
      { {0xd9, 0x4e,   -1}, "    ;clear port 3 interrupt flag"}, //  CLR1   P3INT, 1

      { {0x9f, 0x01,   -1}, ";branch if carry clear"}, // BN     PSW, 7, L0B6F
      { {0x7f, 0x01,   -1}, ";branch if carry set"},   // BP     PSW, 7, L0B8D
      { {0xdf, 0x01,   -1}, ";clear carry flag"},      // CLR1   PSW, 7
      { {0xff, 0x01,   -1}, ";set carry flag"},        // SET1   PSW, 7

      { {0xf9, 0x01,   -1}, "      ;unknown function!"},     // SET1   PSW, 1
      { {0xd9, 0x01,   -1}, "      ;unknown function!"},     // CLR1   PSW, 1

      { {0x30,   -1,   -1}, "               ; B:ACC:C <- ACC:B * C"}, //  MUL
      { {0x40,   -1,   -1}, "               ; ACC:C remainder B <- ACC:B / C"}, //  DIV

      { {-1, -1, -1},      "EOL"}        // ---End of list---
   };



typedef struct {int entry; int exit;} firmwarecall_type;

// List describing entry and exit points for built-in firmware:
// The entry point is the code executed after the instruction that modifies
// the EXT register (typically NOT1 EXT,0); the exit point is where execution
// resumes.
firmwarecall_type FIRMWARECALL[] =
   {  { 0x102, 0x105},  // 
      { 0x112, 0x115},  // 
      { 0x122, 0x125},  // 
      { 0x136, 0x139},  // 
      { 0x1f2,    -1},  // exit vector; doesn't return
      {   -1,     -1}   // end of list
   };