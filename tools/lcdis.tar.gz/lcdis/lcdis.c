/*
 * LCDIS - LC86104C/108C disassembler
 * Copyright 1999 John Maushammer  maushammer@tidalwave.net
 * Portions by Alexander Villagran
 * Helpful suggestions and code fixes from Marcus Comstedt
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *
 * Release notes:
 *   Beta 0.1 - initial beta release
 *   Beta 0.2 - fixed DBNZ bug - not handled by mapmem. Added ascii output.
 *   Beta 0.3 - fixed R16 rollover problem, which was throwing off mapmem and causing it to mess up memory
 *              when it accessed an out-of-bound index. Surprisingly, this only happened in RELEASE, not
 *              DEBUG. Now an out-of-bound PC causes a fatal error.
 *            - a certain branch instruction didn't use print_data_label
 *            - Added use of MEM_INVALID to check for jumps into the middle of existing code (ie. into the
 *              second or third byte of a multi-byte instruction). Usually this means an error, but not
 *              necessarily.
 *   Beta 0.4 - Added user-defined entry points to trace.
 *            - Added call stack trace buffer for errors found during mapmem
 *            - Now labels mapmem entry points (i.e. L0000)
 *   Beta 0.5 - Added graphics disassembly options
 *   Beta 0.6 - Added predefined labels and some auto-commenting of certain code
 *            - Added better display of icon data
 *   Beta 0.61- Added autocommenting of MUL and DIV, some better ANSI compatibility
 *   Beta 0.7 - mapmem thought that "BR" was a conditional branch; it's really always taken.
 *            - mapmem deals with jump to other banks more realistically (FIRMWARECALL)
 *            - mapmem doesn't continue to follow code once it hits an illegal instruction
 *            - removed legacy mem_use[branchaddr]=MEM_CODE_LABELED instructions
 *            - changed "*** WARNING: used as both code and data:" error to more accurate
 *              "*** WARNING: this is the target of a possibly misaligned jump:"
 *              The general behavior here is a bit better.
 *            - Added bad vein checking ("STRICT") so disassembler doesn't run amok and errors
 *              can be found easier.
 *   Beta 0.8 - Added assembly out option, compatible with Marcus's assembler. It doesn't
 *              define variables yet; instead it just uses the address. Tested with boom, football,
 *              and chao - reassembly is an exact match of disassembly.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include <ctype.h>
#include "lcdis.h"

// This define needed for SUN environments:
#if (defined (sparc) || defined (__sparc__) || defined (__sparc))
#define strnicmp(x,y,z) strncasecmp(x,y,z)
#endif

// big ugly global variables:
unsigned char mem[0x10000];     // 64K of memory max.
unsigned char mem_use[0x10000]; // memory usage:
int strictmode=0;               // strict mode that stops at first sign of memmap going amok.
int asmout=0;                   // for compiler-compatible output.

int main (int argc, char * argv[])
{
  FILE * fin;
  int memsize;
  int pin, p1;    // address counters
  int count;
  int i;

  printf ("; LC86104C/108C disassembler. (C) 1999 John Maushammer.\n"
          ";  Beta version 0.8                    maushammer@tidalwave.net\n"
          ";  GNU public liscense - see www.gnu.org\n;\n;\n");

  if (argc < 2)
  {  printf ("lcdis inputfile.vms {[entrypoint] ...}> outputfile\n\n"
             "  STRICT         - kills bad 'veins'; helps prevent disassembly of bad code and\n"
             "                   finds errors, but stops before all good code is disassembled\n"
             "  ASMOUT         - outputs cleaner code for use with an assembler\n"
             "  ENTRYn         - define code starting at address n\n"
             "  GRAPHBYTESn,b  - define b bytes of graphics at address n\n"
             "  GRAPHPAGESn,p  - define p pages (=0xC0 bytes) of graphics at address n\n\n"
             "In addition to the standard entry points, other points can be disassembled.\n"
             "Enter these as parameters after the input file. Use decimal or the 0x notation.\n"
             "Example:\n"
             "    lcdis football.vms ENTRY0x139 > football.lst\n\n");
     return (1);
  }

  printf ("; Source file=%s, ", argv[1]);
  if ( (fin = fopen(argv[1],"rb")) == NULL)
  {  printf ("can not open!\n");
     return (1);
  }

  memset(mem,     0x00,       0x10000); // clear memory
  memset(mem_use, MEM_UNUSED, 0x10000); // clear memory
  memsize=fread((void *) mem, sizeof (char), 0x10000, fin);
  fclose(fin);
  printf ("%d (0x%04x) bytes.\n", memsize, memsize);
  memset(mem_use, MEM_UNKNOWN, memsize); // clear memory

  if (argc >= 3)  // if extra command-line arguments, then parse here
  {
    for (i=2; i<argc; i++)
    {
       if (stricmp(argv[i], "STRICT")==0)
       { 
           printf ("; Strict mode enabled.\n");
           strictmode=1;
       }
       else
       if (stricmp(argv[i], "ASMOUT")==0)
       { 
           printf ("; Assembler output mode output enabled.\n");
           asmout=1;
       }
       else
       if (strnicmp(argv[i], "ENTRY", 5)==0)
       {
           if (1==sscanf(& (argv[i][5]), "%i", &pin))
           {  printf ("; Mapping memory...   user-defined point $%04x\n", pin);
              mapmem (pin);
           }
           else
              printf ("WARNING: cannot parse value in '%s'. Must use decimal or 0x notation.\n", argv[i]);

       }
       else
       if (strnicmp(argv[i], "GRAPHBYTES", 10)==0)
       {
           if (2==sscanf(& (argv[i][10]), "%i,%i", &pin, &count))
           {  printf ("; Mapping graphics... user-defined point $%04x-$%04x ($%04x bytes)\n", pin, pin+count-1, count);
              while (count-- && (pin>=0) && (pin <= 0xFFFF))
                 mem_use[pin++]=MEM_GRAPHICS;
           }
           else
              printf ("WARNING: cannot parse value in '%s'. Must use decimal or 0x notation.\n", argv[i]);

       }
       else
       if (strnicmp(argv[i], "GRAPHPAGES", 10)==0)
       {
           if (2==sscanf(& (argv[i][10]), "%i,%i", &pin, &count))
           {  
              printf ("; Mapping graphics... user-defined point $%04x-$%04x ($%04x pages) \n", pin, pin+(0xC0*count)-1, count);
              count *= 0xC0;    // packed format
              while (count-- && (pin>=0) && (pin <= 0xFFFF))
                 mem_use[pin++]=MEM_GRAPHICS;
           }
           else
              printf ("WARNING: cannot parse value in '%s'. Must use decimal or 0x notation.\n", argv[i]);

       }
       else
       {   printf ("WARNING: unknown command line directive %s\n", argv[i]);
       }
    }
  }


  printf ("; Mapping memory...   reset/start entry point\n");
  mapmem (0x00);  // reset/start
  printf ("; Mapping memory...   interrupt entry points\n");
  mapmem (0x03);  // external interrupt 0?
  mapmem (0x0b);  // timer/counter 0 interrupt
  mapmem (0x13);  // external interrupt 1?
  mapmem (0x1b);  // timer/counter 1 interrupt
  mapmem (0x23);  // divider circuit/port 1/port 3 interrupt?
  mapmem (0x2b);  // interrupt
  mapmem (0x33);  // interrupt
  mapmem (0x3b);  // interrupt
  mapmem (0x43);  // interrupt
  mapmem (0x4b);  // interrupt

  printf ("; Done mapping memory.\n");

  printf ("\n\n;------------------------------------------------------------------\n\n");

  if (asmout)
    printf ("             .include \"sfr.i\"\n\n"
            "             .org 0\n\n\n");

  // simple straight-through disassembly: (all code)
  for (pin=0; pin<memsize; )
  {
     dis(pin, &p1);
     pin = p1;
  }

  return(0);
}


// FUNCTION dis
//
// inputs
//   pin = address counter to disassemble
//
// outputs
//   b1 = address of next instruction (or -1 if RETURN)
//
// Model line:
//   "0593- 23 00 00 |              MOV    #$00,ACC"


void dis (int pin, int * b1)
{
   unsigned char opcode;
   char * model;
   int i,i2;
   int found;

   opcode = mem[pin];

// Debug code to force all memory to be interpreted as code or data:
//   mem_use[pin] = MEM_DATA;
//   mem_use[pin] = MEM_CODE;   // it's executable

   if (pin <0 || pin>0xFFFF)
      printf ("ERROR: attempted to dissassemble illegal address %04x!\n", pin);

   switch (mem_use[pin])
   {
     case MEM_UNUSED:    // not loaded from file
        *b1=-1;          // can't branch anywhere
        break;

     case MEM_UNKNOWN:   // if unknown, then assume it's data
     case MEM_DATA:
        if ((pin >= 0x280) && (pin < 0x280+mem[0x240]*0x200))
        {           // icon data for display on dreamcast
           if (((pin-0x280) & 0x1FF) == 0x0)   // in icon boundry?
           {  if (!asmout)
                 printf ("%04x-          |   ;icon #%d\n", pin, (pin-0x280)/0x200);
              else 
                 printf ("  ;icon #%d\n", (pin-0x280)/0x200);
           }

           if (!asmout)
              printf ("%04x-          | ", pin);
           printf ("             BYTE   $%02x", opcode);

           for (i=1; i<16; i++)
              printf (",$%02x", mem[pin+i]);
           printf ("    ");            // pad to make comment align
           printf ("  ;icon \"");

           for (i=0; i<16; i++)
           {
             if (mem[pin+i] & 0xF0)
                printf ("%x", mem[pin+i]>>4);  // print hex digit 1-F
             else
                printf (" ");                  // print space instead of '0'

             if (mem[pin+i] & 0x0F)
                printf ("%x", mem[pin+i]&0xf);  // print hex digit 1-F
             else
                printf (" ");                  // print space instead of '0'
           }

           printf ("\"");
           *b1=pin+16;   // icons are always lines of 16 bytes
        }
        else
        {           // general data
           if (!asmout)
              printf ("%04x-          | ", pin);
           printf ("             BYTE   $%02x", opcode);
           i=pin+1;
  
           while ( (i & 0x7) &&
                   ( (mem_use[i]==MEM_UNKNOWN) || (mem_use[i]==MEM_UNKNOWN)) )
              printf (",$%02x", mem[i++]);


           // ASCII representation
           for (i2=8-(i-pin); i2; i2--)
             printf ("    ");            // pad to make comment align
           printf ("  ;ascii \"");
           for (i2=pin; i2<i; i2++)
             printf ("%c", (isprint (mem[i2] & 0x7F)) ? (mem[i2] & 0x7F) : '.');
           printf ("\"");
           *b1=i;
        }

        printf ("\n");
        break;

      case MEM_GRAPHICS:
        if (!asmout)
          printf ("%04x-          | ", pin);

        printf ("             BYTE   ");

        printf ("$%02x", mem[pin]);
        for (i=1; i<6; i++)    /* 6 bytes per line */
           printf (",$%02x", mem[pin+i]);

        printf ("          ;graphics \"");
        for (i=0; i<6; i++)    /* 6 bytes per line */
           printf ("%c%c%c%c%c%c%c%c", 
                               mem[pin+i] & 128 ? '#' : '.',
                               mem[pin+i] & 64 ? '#' : '.',
                               mem[pin+i] & 32 ? '#' : '.',
                               mem[pin+i] & 16? '#' : '.',
                               mem[pin+i] & 8 ? '#' : '.',
                               mem[pin+i] & 4 ? '#' : '.',
                               mem[pin+i] & 2 ? '#' : '.',
                               mem[pin+i] & 1 ? '#' : '.');

        printf ("\"\n");
        *b1=pin+6;
        break;

     case MEM_INVALID:
        printf ("*** WARNING: this is the target of a possibly misaligned jump:\n");
        // fall into code section

     case MEM_CODE:
     case MEM_CODE_LABELED:
        if (!asmout)
        {  
           printf ("%04x- ", pin);

           for (i=0; i<3; i++)
              if (i<opcode_len(opcode))// print raw bytes:
                 printf ("%02x ", mem[pin+i]);
              else
                 printf ("   ");

           printf ("| ");
        }
         
        // print label if wanted
        if (mem_use[pin] == MEM_CODE_LABELED)
           print_code_label(pin,1);  // formatted
        else
           printf ("             ");

        model = get_opcode_model(opcode);
        printf ("%5.5s  ", model);

        // calculate next word
        *b1 = pin + opcode_len (opcode);

        switch (model[5])
        {
           case ' ':   // no parameters
              break;

           case '2':   // a12   absolute
              print_code_label (get_a12(pin),0);
              // printf ("$%04x", get_a12(pin));
              break;

           case '6':   // r16   relative
              print_code_label (get_r16(pin),0);
              // printf ("$%04x", get_r16(pin));
              break;

           case '7':   // a16   absolute
              print_code_label (get_a16(pin),0);
              // printf ("$%04x", get_a16(pin));
              break;

           case '8':   // r8    relative
              print_code_label (get_r8(pin),0);
              // printf ("$%04x", get_r8(pin));
              break;

           case '9':   // d9    direct
              print_data_label (get_d9(pin));
              // printf ("$%03x", get_d9(pin));
              break;

           case '@':   // @Ri   indirect
              printf ("@R%d", get_reg(pin));
              break;

           case '#':   // #     immediate
              printf ("#$%02x", mem[pin+1]);
              break;

           case '^':   // ^=#i8,d9 immediate
              printf ("#$%02x,", mem[pin+2]);
              print_data_label (get_d9(pin));
              // printf ("#$%02x,$%03x", mem[pin+2], get_d9(pin));
              break;

           case '%':   // %=#i8,@Ri
              printf ("#$%02x, @R%d", mem[pin+1], get_reg(pin));
              break;

           case 'b':   // b=d9,b3    bit manipulation
              print_data_label(get_d9bit(pin));
              printf (", %d", mem[pin]&7);
              // printf ("$%03x, %d", get_d9bit(pin), mem[pin]&7);
              break;

           case 'r':   // r=d9,b3,r8 bit branch
              print_data_label (get_d9bit(pin));
              printf (", %d, ", mem[pin]&7);
              print_code_label (get_r8(pin+1),0);
              // printf ("$%03x, %d, $%04x", get_d9bit(pin), mem[pin]&7, get_r8(pin+1));
              break;

           case 'z':   // z=#i8,r8
              printf ("#$%02x,", mem[pin+1]);
              print_code_label (get_r8(pin+1),0);
              // printf ("#$%02x,$%04x", mem[pin+1], get_r8(pin+1));
              break;

           case 'x':   // x=d9,r8
              print_data_label (get_d9(pin));
              printf (",");
              print_code_label (get_r8(pin+1),0);
              // printf ("$%03x,$%04x", get_d9(pin), get_r8(pin+1));
              break;

           case 'v':   // v=@Ri,#i8,r8
              printf ("@R%d,#$%02x,", get_reg(pin), mem[pin+1]);
              print_code_label (get_r8(pin+1),0);
              // printf ("@R%d,#$%02x,$%04x", get_reg(pin), mem[pin+1], get_r8(pin+1));
              break;

           case 'c':   // c=@Ri,r8
              printf ("@R%d,", get_reg(pin));
              print_code_label (get_r8(pin),0);
              // printf ("@R%d,$%04x", get_reg(pin), get_r8(pin));
              break;

           case '!':   // illegal
              printf ("$%02d          ;illegal opcode", opcode);
              break;

           default:
              printf ("! ! !\nFATAL Error: unexpected model %c in op[] table!\n", model[5]);
              exit (-1);  // not graceful
        }

//        printf ("       [model %c] ", model[5]);  // helpful for debugging 

  
        // print pre-defined comments for particular instructions:
        found=0;
        for (i=0; (CODECMTS[i].code[0] != -1) && !found; i++)  // check whole list
        {
           found = 1;
           for (i2=0; (i2<3) && found; i2++)
              if ((mem[pin+i2]!=CODECMTS[i].code[i2]) && CODECMTS[i].code[i2] != -1)
                 found=0;   // didn't fit pattern
           if (found)
              printf ("      %s", CODECMTS[i].text);
        }


        printf ("\n");

        // add a blank line after some instructions:
        if (    (strncmp(model, "JMP  ", 5) == 0)
             || (strncmp(model, "JMPF ", 5) == 0)
             || (strncmp(model, "RET", 3) == 0))     // RET and RETI
           printf (asmout ? "\n" : "               |\n");
        break;

      default:
          printf ("FATAL INTERNAL ERROR: unknown type of memory\n");
          exit(-1);
        break;
   }
}



// input: executable address
//
// warning: is fooled by branches that cover both cases
//          i.e. BZ followed by a BNZ will always go to one of those
//          cases, but this code will think that the BNZ case may not
//          execute and continue mapping. Nice programmers would use
//          a BR instruction in the second case, but those that aren't
//          used to such new-fangled technology might not (like me).
//
//          Also, computed gotos (if possible) are not honored
//
// Returns: 0=valid code
//          1=invalid code

int mapmem (int pin_in)
{
   int    branchaddr;
   char * model;
   unsigned char opcode;
   int    i;
   int    pin;                // pc during trace
   int    entry;
   int    badvein;

   static int  level=0;       // static during recursion
   static int  calltrace[200];
// debug variables:
// int x; char junk[200];


   pin=pin_in;                // start trace at passed parameter

   //-- record mapmem recursion
   if (level<200)
      calltrace[level]=pin;
   level++;
   //--

   while (1)
   {

      if (pin <0 || pin>0xFFFF)
      {   printf ("FATAL INTERNAL ERROR: attempted to map illegal address %04x!\n", pin);
          exit (-1);
      }

      if (    (mem_use[pin] == MEM_DATA)       // <- this is impossible so far because we don't mark any code data yet.
           || (mem_use[pin] == MEM_GRAPHICS)
           || (mem_use[pin] == MEM_UNUSED))
      {
         printf ("WARNING: branch exists to data/graphics/unused code at $%04x\n"
                 "         trace stack: ", pin);
         for (i=0; i<level; i++)
           printf ("%04x ", calltrace[i]);
         printf ("\n\n");
         level--;
         mem_use[pin_in] = MEM_INVALID;  // we'll label it invalid.
         return 1;    // only explore the good stuff
      }
      if (mem_use[pin] == MEM_INVALID)
      {
         printf ("WARNING: branch exists to invalid code at $%04x\n"
                 "         trace stack: ", pin);
         for (i=0; i<level; i++)
           printf ("%04x ", calltrace[i]);
         printf ("\n\n");
         level--;
         return 1;    // only explore the good stuff
      }

      if (mem_use[pin] != MEM_UNKNOWN)
      {
         level--;
         mem_use[pin_in] = MEM_CODE_LABELED;  // we'll label the main entry point 
         return 0;    // only explore the unknown
      }

      mem_use[pin] = MEM_CODE;   // it's executable

///// use one or both of these for debugging:
/////dis(pin, &x);
/////gets (junk);

      opcode = mem[pin];
      model = get_opcode_model(opcode);

      // Flag illegal code
      if (model[5] == '!')
      {
         printf ("WARNING: illegal instruction found at $%04x\n"
                 "         trace stack: ", pin);
         for (i=0; i<level; i++)
           printf ("%04x ", calltrace[i]);
         printf ("\n\n");
         level--;    // don't continue to follow this vein
         return 1;   // and tell caller not to, either.
      }

      if (strncmp(model, "CALL ", 5) == 0)
      {
         branchaddr = get_a12(pin);
         badvein=mapmem(branchaddr);                // recurse
         if (badvein && strictmode)
         {  level--;
            mem_use[pin_in] = MEM_CODE_LABELED;  // we'll label the main entry point
            return 1;                                  // end of the line 
         }
      }
      else
      if (strncmp(model, "CALLF", 5) == 0)
      {
         branchaddr = get_a16(pin);
         badvein=mapmem(branchaddr);                // recurse
         if (badvein && strictmode)
         {  level--;
            mem_use[pin_in] = MEM_CODE_LABELED;  // we'll label the main entry point
            return 1;                                  // end of the line 
         }
      }
      else
      if (strncmp(model, "CALLR", 5) == 0)
      {
         branchaddr = get_r16(pin);
         badvein=mapmem(branchaddr);                // recurse
         if (badvein && strictmode)
         {  level--;
            mem_use[pin_in] = MEM_CODE_LABELED;  // we'll label the main entry point
            return 1;                                  // end of the line 
         }
      }
      else
      if (strncmp(model, "JMP  ", 5) == 0)
      {
         branchaddr = get_a12(pin);
         badvein=mapmem(branchaddr);                  // recurse
         level--;
         mem_use[pin_in] = MEM_CODE_LABELED;  // we'll label the main entry point
         return badvein;                                  // end of the line
      }
      else
      if (strncmp(model, "JMPF ", 5) == 0)
      {
         branchaddr = get_a16(pin);
         badvein=mapmem(branchaddr);                 // recurse
         level--;
         mem_use[pin_in] = MEM_CODE_LABELED;  // we'll label the main entry point
         return badvein;
      }
      else
      if (strncmp(model, "RET", 3) == 0)     // RET and RETI
      {
         level--;
         mem_use[pin_in] = MEM_CODE_LABELED;  // we'll label the main entry point
         return 0;                            // a dead-end
      }
      else
      if (strncmp(model, "BRF  ", 5) == 0)
      {
         branchaddr = get_r16(pin);
         badvein=mapmem(branchaddr);                        // recurse
         level--;
         mem_use[pin_in] = MEM_CODE_LABELED;        // we'll label the main entry point
         return badvein;                                  // a dead end
      }
      else
      if (strncmp(model, "BR   ", 5) == 0)
      {
         branchaddr = get_r8(pin);
         badvein=mapmem(branchaddr);                // recurse
         level--;
         mem_use[pin_in] = MEM_CODE_LABELED;        // we'll label the main entry point
         return badvein;                            // a dead end
      }
      else       // These branch instructions are all assumed to be takeable or non-taken:
      if (   (model[0]=='B')                     // if branch instruction
          || (strncmp(model, "DBNZ ", 5) == 0))  // funnily named branch instruction
      {
         switch (model[5])
         {
            case '8':   // r8    relative
            case 'c':   // c=@Ri,r8
               branchaddr= get_r8(pin);
               break;
            case 'r':   // r=d9,b3,r8 bit branch
               branchaddr= get_r8(pin+1);
               break;
            case 'z':   // z=#i8,r8
            case 'x':   // x=d9,r8
            case 'v':   // v=@Ri,#i8,r8
               branchaddr= get_r8(pin+1);
               break;

            default:
               printf ("FATAL Error: unexpected branch model %c in op[] table!\n", model[5]);
         }
         badvein=mapmem(branchaddr);                   // recurse
         if (badvein && strictmode)
         {  level--;
            mem_use[pin_in] = MEM_CODE_LABELED;  // we'll label the main entry point
            return 1;                                  // end of the line 
         }
      }
      else   // Code could change execution location by switching banks:
      if ( (mem[pin] == 0xB8) && (mem[pin+1]==0x0D) )  // {0xB8, 0x0D,   -1} NOT1   EXT, 0
      {
         entry= pin + opcode_len(opcode);  // calc PC of code after this instruction 
                                           // (always 2 now, but might be 1 if some other way of modifing EXT is trapped)
         for (i=0; FIRMWARECALL[i].entry != -1; i++)
         {
            if (FIRMWARECALL[i].entry == entry)    // did we find exit?
            {
               // special case: after the NOT1 EXT,0 instruction, there is some code
               // that doesn't look like it's executed, but looks like its inserted
               // "just in case". Usually it's a jump to try the NOT1 EXT,0 portion
               // again. It may be junk code. We'll disassemble just one opcode to
               // make it look pretty.
               if (mem_use[entry] == MEM_UNKNOWN)   // if it would otherwise not be disassembled...
                  mem_use[entry] = MEM_CODE;

               if (FIRMWARECALL[i].exit == -1)  
               {                        // treat like a return (this is the exit vector)
                  level--;
                  mem_use[pin_in] = MEM_CODE_LABELED;  // we'll label the main entry point
                  return 0;                            // a dead end
               }
               else
               {                        // treat like a jump
                  badvein=mapmem(FIRMWARECALL[i].exit);        // recurse
                  level--;
                  mem_use[pin_in] = MEM_CODE_LABELED;  // we'll label the main entry point

                  return badvein;                            // a dead end
               }
            }
         }

         printf ("WARNING: NOT1 EXT,0 encountered at unexpected address %04x.\n"
                 "         This code calls a routine in the firmware and the return address\n"
                 "         is unknown (not in FIRMWARECALL table).\n\n", entry);
         level--;
         mem_use[pin_in] = MEM_CODE_LABELED;  // we'll label the main entry point
         return 1;                            // a dead end since we don't know where to go
         // we consider this an error because it is unexpected code.
      }

      // continue evaluating code until end
      pin++;   // usage for pin has been marked as code already

      // mark remaining bytes of this instruction as code
      for (i=0; i<opcode_len(opcode)-1; i++)
      {
         if (mem_use[pin] != MEM_UNKNOWN)
         {
            printf ("WARNING: misaligned code found at $%04x\n"
                 "         trace stack: ", pin);
            for (i=0; i<level; i++)
              printf ("%04x ", calltrace[i]);
            printf ("\n\n");

            mem_use[pin_in] = MEM_CODE_LABELED;  // we'll label the main entry point
            return 1;    // don't continue in this vein because it's messed up (probably)
                         // see example below
         }

         mem_use[pin++] = MEM_INVALID;
           // mark 2nd through 3rd bytes of an instruction as invalid parts to start executing.
           // This is a good assumption, but some people are really tricky and do this on purpose
           //
           // 6502 Example:      CMP #$13    ;return if A=13
           //                    BEQ x1+1
           //                X1: BEQ $60     ; this branch is never taken. $60 opcode is RET and is executed if A=13
           //                                ; you could put a clear-carry there, instead, if you wanted C clear on A=13
           //                    ...
      }

   }  // while 1
}




int opcode_len (int opcode)
{
   char * model;

   model = get_opcode_model(opcode);

   switch (model[5])
   {

     case ' ':   // no parameters
     case '@':   // @Ri   indirect
     case '!':   // illegal
        return 1;

     case '2':   // a12   absolute
     case '8':   // r8    relative
     case '9':   // d9    direct
     case '#':   // #     immediate
     case '%':   // %=#i8,@Ri
     case 'b':   // b=d9,b3    bit manipulation
     case 'c':   // c=@Ri,r8
        return 2;

     case '6':   // r16   relative
     case '7':   // a16   absolute
     case '^':   // ^=#i8,d9 immediate
     case 'r':   // r=d9,b3,r8 bit branch
     case 'z':   // z=#i8,r8
     case 'x':   // x=d9,r8
     case 'v':   // v=@Ri,#i8,r8
        return 3;
   }
}


//------------------------------------------------------------------------------------
// get_opcode_model
//  in: opcode
// out: pointer to model of opcode
//------------------------------------------------------------------------------------

char * get_opcode_model (int opcode)
{
   //lookup table saves table entries and make op[] match LC86104C datasheet

                        //0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15
   static int lookup[16]={0,1,2,2,3,3,3,3,4,4,4, 4, 4, 4, 4, 4};

   return op[lookup[opcode & 0x0F] + (opcode >> 4)*5];
}



//---0---- ---1---- --2,3--- --4-7--- --8-F---


// Format: 5 chars=NAME
//         1 char= param   template
//                  =      nop
//                 2=a12   absolute
//                 6=r16   relative 16
//                 7=a16   absolute 16
//                 8=r8    relative 8
//                 9=d9
//                 @=@Ri   indirect
//                 #=#i8   immediate
//                 ^=#i8,d9 immediate
//                 %=#i8,@Ri
//                 b=d9,b3    bit manipulation
//                 r=d9,b3,r8 bit branch
//                 z=#i8,r8
//                 x=d9,r8
//                 v=@Ri,#i8,r8
//                 c=@Ri,r8
//                 !       invalid!


int get_a12(int pin)
{
  return (  ((pin+2) & 0xF000)               // get first part from PC
          | ((mem[pin] & 0x07) << 8 )        // get some bits
          | ((mem[pin] & 0x10) ? 0x800 : 0)  // out of place bit
          | (mem[pin+1]));                   // lower 8 bits
}


int get_r16(int pin)
{ // warning: byte order is reversed of A16!
  return ( 0xFFFF & (pin + 3 - 1 +(mem[pin+2]<<8 | mem[pin+1])));
}


int get_a16(int pin)
{
  return (mem[pin+1]<<8 | mem[pin+2]);
}

int get_r8(int pin)
{
   return ( 0xFFFF & (pin + 2 + (int) ((char) mem[pin+1])));
}

int get_d9(int pin)
{
   return ( (mem[pin]&1)<<8 | mem[pin+1]);
}
int get_d9bit(int pin)
{
   return ( (mem[pin]&0x10)<<4 | mem[pin+1]);
}

int get_reg(int pin)
{
   return (mem[pin] & 0x3);
}


// could be modified to return SFR comments, or to identify
// registers (MEM00-MEM0F) which isn't done because they may
// not all be used as registers (depends on PSW)

void print_data_label (int addr)
{
   int found;
   int i;


   if (addr < 0x100)
   {
      if (!asmout)
         printf ("MEM%03X", addr);
      else
         printf ("$%03x", addr); //  !!! could be fixed up !!!
   }
   else
   {
      found=0;
      for (i=0; (SFR[i].addr != -1) && (!found); i++)
         if (addr == SFR[i].addr)
         {
            printf ("%s", SFR[i].text);
            found++;
         }

      if (!found)
      {
         if (!asmout)
            printf ("SFR%03X", addr);
         else
            printf ("$%03x", addr); //  !!! could be fixed up !!!
      }
   }
}

// print code label
//      addr: address
// formatted: 0=just the text, ma'am
//            1=add the colon and print exactly 13 characters
void print_code_label (int addr, int formatted)
{
   int found;
   int i;
   char temp[50];

   found=0;
   for (i=0; (LABELS[i].addr != -1) && (!found); i++)
      if (addr == LABELS[i].addr)
      {
         if (formatted)
         {   
            sprintf (temp,"%s:", LABELS[i].text);   // add the colon
            printf ("%-13s", temp);                 // fill to 13 spaces
         }
         else
            printf ("%s", LABELS[i].text);
         found++;
      }
   if (!found)
   {
      printf ("L%04X", addr);
      if (formatted)
        printf (":       ");
   }
}


// Debug function
// calculates a checksum of entire vmu memory.
// (I used this to help track down an array index out-of-bounds error)

int checkmem(void)
{
  int i, j=0;
  for (i=0; i<0x10000; i++)
    j+=mem[i]*(i+1);
  printf ("Checkmem: %08x\n",j);
  return j;
}
